"""
Scrapes a website to extract blog structure, tone, and style context.
Uses requests + BeautifulSoup for static sites.
Falls back to Playwright for JS-rendered sites.
"""
import re
import logging
from urllib.parse import urljoin, urlparse
from typing import Optional

import requests
from bs4 import BeautifulSoup

logger = logging.getLogger(__name__)

SCRAPE_HEADERS = {
    'User-Agent': ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
                   'AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36')
}

MAX_PAGES = 10   # crawl up to 10 pages per website


def scrape_website(url: str) -> dict:
    """
    Entry point. Returns dict with:
    - pages: list of {url, title, headings, text, word_count}
    - structure_summary: str (raw text to feed to AI)
    """
    pages = []
    visited = set()
    to_visit = [url]
    base_domain = urlparse(url).netloc

    while to_visit and len(pages) < MAX_PAGES:
        current_url = to_visit.pop(0)
        if current_url in visited:
            continue
        visited.add(current_url)

        page_data = _scrape_page(current_url)
        if not page_data:
            continue

        pages.append(page_data)

        # Discover internal links
        for link in page_data.get('internal_links', []):
            if link not in visited and urlparse(link).netloc == base_domain:
                to_visit.append(link)

    return {
        'pages': pages,
        'structure_summary': _build_summary(pages),
    }


def _scrape_page(url: str) -> Optional[dict]:
    try:
        resp = requests.get(url, headers=SCRAPE_HEADERS, timeout=15)
        resp.raise_for_status()
        
        # Try Playwright fallback for JS-heavy pages (minimal content detected)
        soup = BeautifulSoup(resp.text, 'html.parser')
        
        # Remove noise
        for tag in soup(['script', 'style', 'nav', 'footer', 'header',
                         'aside', 'form', 'iframe', 'noscript']):
            tag.decompose()
        
        title = soup.title.string.strip() if soup.title else ''
        
        # Extract heading structure
        headings = []
        for level in ['h1', 'h2', 'h3']:
            for h in soup.find_all(level)[:10]:  # cap at 10 per level
                text = h.get_text(strip=True)
                if text:
                    headings.append({'level': level, 'text': text})
        
        # Main body text
        main = soup.find('main') or soup.find('article') or soup.find('body')
        text = main.get_text(separator=' ', strip=True) if main else ''
        text = re.sub(r'\s+', ' ', text)[:3000]   # cap at 3000 chars per page
        
        # Internal links
        internal_links = []
        base = urlparse(url)
        for a in soup.find_all('a', href=True):
            href = urljoin(url, a['href'])
            if urlparse(href).netloc == base.netloc:
                internal_links.append(href.split('?')[0].split('#')[0])
        
        return {
            'url': url,
            'title': title,
            'headings': headings,
            'text': text,
            'word_count': len(text.split()),
            'internal_links': list(set(internal_links))[:20],
        }
    
    except requests.RequestException as e:
        logger.warning(f"Failed to scrape {url}: {e}")
        return None


def _scrape_page_playwright(url: str) -> Optional[dict]:
    """Fallback for JS-rendered websites."""
    try:
        from playwright.sync_api import sync_playwright
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            page = browser.new_page()
            page.goto(url, timeout=20000, wait_until='networkidle')
            html = page.content()
            browser.close()
        
        soup = BeautifulSoup(html, 'html.parser')
        # ... same extraction as above
        return _extract_from_soup(soup, url)
    except Exception as e:
        logger.error(f"Playwright fallback failed for {url}: {e}")
        return None


def _build_summary(pages: list) -> str:
    """Builds a text summary of the website structure to use as AI context."""
    lines = []
    for p in pages:
        lines.append(f"PAGE: {p['title']} ({p['url']})")
        for h in p['headings'][:5]:
            lines.append(f"  {h['level'].upper()}: {h['text']}")
        lines.append(f"  EXCERPT: {p['text'][:300]}")
        lines.append("")
    return '\n'.join(lines)