from celery import shared_task
import logging
from django.utils import timezone

from .models import Website, ScrapeResult
from .scraper import scrape_website
from logs.models import ActivityLog

logger = logging.getLogger(__name__)


@shared_task(bind=True, max_retries=3)
def crawl_website_task(self, website_id: int):
    try:
        website = Website.objects.get(pk=website_id)
        website.scrape_status = 'crawling'
        website.save(update_fields=['scrape_status'])
        
        result = scrape_website(website.url)
        
        # Store individual pages
        ScrapeResult.objects.filter(website=website).delete()  # fresh crawl
        for page in result['pages']:
            ScrapeResult.objects.create(
                website=website,
                page_url=page['url'],
                page_title=page['title'],
                raw_text=page['text'],
                heading_structure=page['headings'],
            )
        
        # Use AI to summarize the style/tone and extract metadata
        from content.generator import summarize_website_style, analyze_website_context
        style_summary = summarize_website_style(result['structure_summary'])
        
        try:
            analysis = analyze_website_context(result['structure_summary'])
            website.industry = analysis.get('industry', website.industry or 'General')
            website.tone = analysis.get('tone', website.tone or 'Professional')
            website.topics = analysis.get('topics', website.topics)
            website.brand_colors = analysis.get('brand_colors', website.brand_colors)
            website.avg_read_time = analysis.get('avg_read_time', website.avg_read_time)
        except Exception as e:
            logger.error(f"Task context analysis error: {e}")
            
        website.scrape_summary = style_summary
        website.scrape_status = 'done'
        website.last_crawled = timezone.now()
        website.save(update_fields=['scrape_summary', 'scrape_status', 'last_crawled', 'industry', 'tone', 'topics', 'brand_colors', 'avg_read_time'])
        
        ActivityLog.objects.create(
            actor=None, actor_name='System',
            action='crawl_done', target_description=website.name
        )
        logger.info(f"Crawl completed for {website.name}")
        return {'status': 'done', 'pages': len(result['pages'])}
    
    except Exception as exc:
        logger.error(f"Crawl failed for website {website_id}: {exc}")
        Website.objects.filter(pk=website_id).update(scrape_status='failed')
        raise self.retry(exc=exc, countdown=60)