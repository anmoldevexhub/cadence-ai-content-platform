from rest_framework import serializers
from .models import Website, SocialConnection, ScrapeResult

class SocialConnectionSerializer(serializers.ModelSerializer):
    class Meta:
        model = SocialConnection
        fields = ['id', 'platform', 'make_webhook_url', 'is_active', 'connected_at']
        read_only_fields = ['id', 'connected_at']

class ScrapeResultSerializer(serializers.ModelSerializer):
    class Meta:
        model = ScrapeResult
        fields = ['id', 'page_url', 'page_title', 'raw_text', 'heading_structure', 'crawled_at']

class WebsiteSerializer(serializers.ModelSerializer):
    social_connections = SocialConnectionSerializer(many=True, read_only=True)
    owner_email = serializers.EmailField(source='owner.email', read_only=True)
    owner_name = serializers.CharField(source='owner.get_full_name', read_only=True)
    
    class Meta:
        model = Website
        fields = [
            'id', 'name', 'domain', 'url', 'industry', 'tone', 'topics',
            'status', 'color', 'brand_colors', 'avg_read_time', 'owner', 'owner_email', 'owner_name',
            'created_at', 'updated_at', 'scrape_summary', 'scrape_status',
            'last_crawled', 'social_connections'
        ]
        read_only_fields = ['id', 'created_at', 'updated_at', 'owner']