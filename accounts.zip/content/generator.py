"""
OpenAI-powered content generation.
Uses gpt-4o-mini (cheapest capable model).
"""
import logging
from openai import OpenAI
from decouple import config

from websites.models import Website, ScrapeResult
from .models import ContentIdea, ContentDraft

logger = logging.getLogger(__name__)
client = OpenAI(api_key=config('OPENAI_API_KEY'))

MODEL = 'gpt-4o-mini'   # cheapest OpenAI model, ~$0.15/1M input tokens


def summarize_website_style(structure_text: str) -> str:
    """
    Called after crawl. Returns a concise style guide for the website.
    Stored in Website.scrape_summary for reuse in all future generation.
    """
    prompt = f"""Analyze this website structure and extract:
1. Writing tone (formal/casual/technical/conversational)
2. Typical blog post structure (intro pattern, heading style, CTAs, length)
3. Key topics and recurring themes
4. Vocabulary / brand voice markers
5. Any SEO patterns observed

Website structure:
{structure_text[:6000]}

Return a concise style guide (under 400 words) that an AI writer should follow 
when creating content for this website. Be specific and actionable."""
    
    response = client.chat.completions.create(
        model=MODEL,
        messages=[{'role': 'user', 'content': prompt}],
        max_tokens=600,
        temperature=0.3,
    )
    return response.choices[0].message.content


def build_system_prompt(website: Website) -> str:
    """Builds the persistent system prompt for content generation, including detailed style guide if present."""
    style_details = ""
    if website.style_guide:
        # Convert JSON style guide to readable bullet points
        import json
        try:
            guide = website.style_guide if isinstance(website.style_guide, dict) else json.loads(website.style_guide)
            parts = []
            for key, val in guide.items():
                parts.append(f"- {key}: {val}")
            style_details = "\n" + "\n".join(parts)
        except Exception:
            style_details = "\n" + str(website.style_guide)
    return f"""You are an expert content writer for {website.name} ({website.domain}).

WEBSITE STYLE GUIDE:
{website.scrape_summary or "No style guide available yet. Write in a professional, engaging tone."}{style_details}

BRAND VOICE: {website.tone or "Professional and engaging"}
KEY TOPICS: {", ".join(website.topics) if website.topics else "General content"}
INDUSTRY: {website.industry or "General"}

Always match the website's existing tone and structure exactly.
When writing blog posts:
- Always write a detailed, comprehensive, deep-dive article of at least 900 to 1200 words.
- Avoid brief outlines or summaries. Elaborate on every point with detailed paragraphs (at least 3-4 sentences per paragraph) and sub-sections to satisfy this word count requirement.
- Do not stop until you have covered the topic in full depth.

Never break character or mention that you are an AI."""


def search_live_data(query: str) -> str:
    """
    Searches DuckDuckGo HTML for query and extracts snippet descriptions.
    """
    import requests
    from bs4 import BeautifulSoup
    from urllib.parse import quote_plus

    headers = {
        'User-Agent': ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
                       'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36')
    }
    url = f"https://html.duckduckgo.com/html/?q={quote_plus(query)}"
    try:
        resp = requests.get(url, headers=headers, timeout=10)
        resp.raise_for_status()
        soup = BeautifulSoup(resp.text, 'html.parser')
        
        snippets = []
        for i, a in enumerate(soup.find_all('a', class_='result__snippet')[:4], 1):
            text = a.get_text(strip=True)
            if text:
                snippets.append(f"[{i}] {text}")
        if snippets:
            return "\n".join(snippets)
    except Exception as e:
        logger.warning(f"Live DDG search failed for query '{query}': {e}")
    return "No live data available."


def generate_blog_post(idea: ContentIdea, website: Website) -> dict:
    """Generates a full blog post (HTML-ready) utilizing crawled styles and live search data."""
    system_prompt = build_system_prompt(website)
    
    # Perform live web search to retrieve current facts & context
    logger.info(f"Performing live search for topic: {idea.title}")
    live_data = search_live_data(idea.title)
    
    user_prompt = f"""Write a complete, high-quality, plagiarism-free, and SEO-optimized blog post for {website.name}.

TOPIC: {idea.title}
ADDITIONAL CONTEXT FROM ADMIN: {idea.context or "None provided."}
TARGET TAGS/KEYWORDS: {", ".join(idea.meta_tags) if idea.meta_tags else "Auto-select relevant keywords"}

LIVE SEARCH DATA (Use these real-time facts/details to ground the article in current context):
{live_data}

BLOG REQUIREMENTS:
- Length: Minimum 900 words. Be comprehensive, detailed, and highly informative. You MUST write at least 6-8 long, detailed sections. Make sure each section is thorough so the total word count is guaranteed to be at least 900 words.
- Structural density: For approximately every 300 words of content, you MUST include:
  1. One specific, simple real-world example (e.g. a simple real-life scenario, case study, or concrete illustration) to make the text easy to understand.
  2. One critical tradeoff, limitation, or counter-perspective.
  3. One practical, actionable takeaway for the reader.
  Since the blog post is at least 900 words, you must feature at least 3 examples, 3 tradeoffs, and 3 practical takeaways distributed throughout the article.
- Structure: Proper headings hierarchy (use <h2> and <h3>, NOT <h1> which is reserved for the page title). Use short paragraphs, and bullet points where relevant.
- Include: An engaging introduction, multiple structured main content sections, a clear conclusion, and a call to action (CTA).
- Tone & Humanization Directives:
  * You MUST write in simple, everyday English. Avoid complex jargon, flowery words, and academic phrasing.
  * You MUST avoid AI clichés and words like: "delve", "tapestry", "revolutionize", "moreover", "journey", "in conclusion", "fast-paced world", "furthermore", "testament", "demystify", "gatekeep", "transformative", "crucial", "essential".
  * Write with a natural, conversational, human-like voice. It should sound like a helpful, experienced person sharing their thoughts, rather than an AI text engine.
  * Pay close attention to the writing style, vocabulary patterns, and layouts observed in the WEBSITE STYLE GUIDE.
  * The first paragraph must be engaging and written in a natural, human tone. Avoid generic AI-style introductions (such as 'In today's fast-paced digital world...' or 'In this blog post, we will explore...'). Use simple language, keeping it conversational, relatable, and value-driven right from the start.

SEO REQUIREMENTS:
- Meta Title: Use the same blog title as the Meta Title. The title/Meta Title MUST be between 55 to 60 characters in length. Adjust or trim the wording slightly to fit this exact range if necessary.
- Meta Description: Create a compelling summary that is exactly between 155 and 160 characters in length.
- Category: Assign the most appropriate category based on the topic. Examples of mappings:
  * "Why Some Businesses Need a Web Application Instead of a Website" -> "Web Development"
  * "What Are AI Agents and How Can They Help Businesses?" -> "Artificial Intelligence"
  * "How Machine Learning Is Revolutionizing Customer Experience" -> "Customer Experience / Machine Learning"
  * "How Goal-Based Agents Help AI Make Better Decisions" -> "Artificial Intelligence / Goal-Based Agents"
  * For other topics, infer a similar relevant professional category name.

Format Requirements:
Return ONLY a valid JSON object with these exact keys:
{{
  "title": "...",
  "meta_description": "...",
  "category": "...",
  "tags": ["tag1", "tag2", ...],
  "excerpt": "...(2-3 sentence preview)...",
  "body": "...(full blog post in plain HTML using <h2>, <h3>, <p>, <ul>, <li>)..."
}}

Do NOT include any markdown code block formatting (like ```json ... ```). Return ONLY the raw JSON."""

    response = client.chat.completions.create(
        model=MODEL,
        messages=[
            {'role': 'system', 'content': system_prompt},
            {'role': 'user', 'content': user_prompt},
        ],
        max_tokens=2000,
        temperature=0.7,
        response_format={"type": "json_object"},
    )
    
    import json
    content = json.loads(response.choices[0].message.content)
    content['generation_prompt'] = user_prompt
    return content


def generate_social_post(idea: ContentIdea, website: Website, platform: str) -> dict:
    """Generates platform-specific social media content."""
    limits = {
        'instagram': 'Under 150 words. Casual, emoji-rich, 3-5 hashtags.',
        'linkedin': 'Under 200 words. Professional tone. No emojis. Hook first line.',
        'facebook': 'Under 120 words. Conversational. Include a question to drive comments.',
        'youtube': 'Video description: 150-200 words. Include timestamps section and subscribe CTA.',
        'twitter': 'Under 280 characters. Punchy. One insight.',
    }
    
    instructions = limits.get(platform, 'Under 200 words, platform-appropriate.')
    system_prompt = build_system_prompt(website)
    
    user_prompt = f"""Write a {platform.title()} post for {website.name}.

TOPIC: {idea.title}
ADMIN CONTEXT: {idea.context or "None"}
FORMAT RULES: {instructions}

Return JSON:
{{
  "title": "...(internal label)...",
  "body": "...(the actual post text)...",
  "excerpt": "...(same as body for social)...",
  "tags": ["hashtag1", "hashtag2"],
  "meta_description": ""
}}

Return ONLY the JSON."""

    response = client.chat.completions.create(
        model=MODEL,
        messages=[
            {'role': 'system', 'content': system_prompt},
            {'role': 'user', 'content': user_prompt},
        ],
        max_tokens=600,
        temperature=0.8,
        response_format={"type": "json_object"},
    )
    
    import json
    content = json.loads(response.choices[0].message.content)
    content['generation_prompt'] = user_prompt
    return content


def wrap_text(text: str, max_chars: int) -> list:
    words = text.split()
    lines = []
    current_line = []
    current_length = 0
    for word in words:
        if current_length + len(word) + 1 > max_chars:
            lines.append(" ".join(current_line))
            current_line = [word]
            current_length = len(word)
        else:
            current_line.append(word)
            current_length += len(word) + 1
    if current_line:
        lines.append(" ".join(current_line))
    return lines


def build_svg_from_data(data: dict) -> str:
    theme = data.get("theme", "theme1")
    title_lines = data.get("title_lines", [])
    subtext = data.get("subtext", "")
    cta_text = data.get("cta_text", "READ MORE")
    badges = data.get("badges", [])
    
    screen_data = data.get("laptop_screen", {})
    screen_title = screen_data.get("title", "DEVEX").strip()
    screen_subtitle = screen_data.get("subtitle", "Success Guide").strip()
    
    # Escape screen titles for SVG
    screen_title_esc = screen_title.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    screen_subtitle_esc = screen_subtitle.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    # Check for custom logo in media folder
    from django.conf import settings
    import os
    import base64
    
    custom_logo_data_uri = None
    media_dir = os.path.join(settings.BASE_DIR, 'frontend', 'media')
    try:
        for ext in ['svg', 'png', 'jpg', 'jpeg']:
            logo_path = os.path.join(media_dir, f'devexhub_logo.{ext}')
            if os.path.exists(logo_path):
                with open(logo_path, 'rb') as f:
                    encoded = base64.b64encode(f.read()).decode('utf-8')
                mime = f"image/{ext}" if ext != 'svg' else "image/svg+xml"
                custom_logo_data_uri = f"data:{mime};base64,{encoded}"
                break
    except Exception:
        pass
        
    if custom_logo_data_uri:
        if theme == "theme3":
            # Blends directly with the white background of Theme 3
            logo_content_svg = f'<image href="{custom_logo_data_uri}" x="0" y="0" width="100" height="100"/>'
        else:
            # Framed in a white card overlay to pop nicely against the dark sidebars of Theme 1 & 2
            logo_content_svg = f"""<rect x="-10" y="-10" width="120" height="120" rx="12" fill="#ffffff" filter="url(#shadow)"/>
    <image href="{custom_logo_data_uri}" x="0" y="0" width="100" height="100"/>"""
    else:
        logo_content_svg = """<rect x="0" y="0" width="56" height="56" rx="10" fill="none" stroke="currentColor" stroke-width="3"/>
    <polygon points="28,8 42,15 28,22 14,15" fill="currentColor"/>
    <path d="M 21 16 L 21 21 Q 28 25 35 21 L 35 16" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"/>
    <path d="M 42 15 L 44 22 L 44 26" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
    <rect x="21" y="26" width="5" height="18" rx="1.5" fill="currentColor"/>
    <rect x="30" y="26" width="5" height="18" rx="1.5" fill="currentColor"/>
    <rect x="25" y="32" width="6" height="4" fill="currentColor"/>"""

    # 1. Render title lines
    title_lines_svg = []
    y_offset = 0
    for line in title_lines:
        text = line.get("text", "").strip()
        ltype = line.get("type", "plain")
        text_escaped = text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        
        if not text_escaped:
            continue
            
        if ltype == "boxed":
            box_width = len(text) * 22 + 20
            if box_width < 120:
                box_width = 120
            if theme == "theme3":
                title_lines_svg.append(f'<rect x="-10" y="{y_offset - 38}" width="{box_width}" height="50" rx="6" fill="none" stroke="#0a122c" stroke-width="2.5"/>')
                title_lines_svg.append(f'<text x="0" y="{y_offset}" font-family="system-ui, -apple-system, sans-serif" font-weight="900" font-size="36" fill="#0a122c">{text_escaped}</text>')
            else:
                title_lines_svg.append(f'<rect x="-10" y="{y_offset - 38}" width="{box_width}" height="50" rx="6" fill="none" stroke="#ffffff" stroke-width="2.5"/>')
                title_lines_svg.append(f'<text x="0" y="{y_offset}" font-family="system-ui, -apple-system, sans-serif" font-weight="900" font-size="36" fill="#ffffff">{text_escaped}</text>')
        elif ltype == "accent":
            if theme == "theme2":
                title_lines_svg.append(f'<text x="0" y="{y_offset}" font-family="system-ui, -apple-system, sans-serif" font-weight="900" font-size="36" fill="#22d3ee">{text_escaped}</text>')
            elif theme == "theme3":
                title_lines_svg.append(f'<text x="0" y="{y_offset}" font-family="system-ui, -apple-system, sans-serif" font-weight="900" font-size="36" fill="#0284c7">{text_escaped}</text>')
            else:
                title_lines_svg.append(f'<text x="0" y="{y_offset}" font-family="system-ui, -apple-system, sans-serif" font-weight="900" font-size="36" fill="#38bdf8">{text_escaped}</text>')
        else:
            if theme == "theme3":
                title_lines_svg.append(f'<text x="0" y="{y_offset}" font-family="system-ui, -apple-system, sans-serif" font-weight="900" font-size="36" fill="#0a122c">{text_escaped}</text>')
            else:
                title_lines_svg.append(f'<text x="0" y="{y_offset}" font-family="system-ui, -apple-system, sans-serif" font-weight="900" font-size="36" fill="#ffffff">{text_escaped}</text>')
        y_offset += 54
        
    title_lines_svg_str = "\n    ".join(title_lines_svg)

    # 2. Render subtext lines
    subtext_lines = wrap_text(subtext, 42)
    subtext_svg_lines = []
    dy = 0
    for sline in subtext_lines:
        sline_escaped = sline.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        subtext_svg_lines.append(f'<tspan x="80" dy="{dy}">{sline_escaped}</tspan>')
        dy = 24
    subtext_svg_str = "\n    ".join(subtext_svg_lines)

    # 3. Render badges and connections
    badge_positions = [
        (650, 140),
        (840, 100),
        (1010, 150),
        (1030, 450)
    ]
    badges_svg_lines = []
    connections_svg_lines = []
    
    if theme == "theme2":
        stroke_color = "#d946ef"
    elif theme == "theme3":
        stroke_color = "#cbd5e1"
    else:
        stroke_color = "#94a3b8"
        
    # Standard connection lines (dotted)
    connections_svg_lines.append(f'<path d="M 720 182 Q 720 280 810 280" fill="none" stroke="{stroke_color}" stroke-width="2" stroke-dasharray="4,4"/>')
    connections_svg_lines.append(f'<path d="M 890 142 Q 890 260 840 260" fill="none" stroke="{stroke_color}" stroke-width="2" stroke-dasharray="4,4"/>')
    connections_svg_lines.append(f'<path d="M 1010 192 Q 970 260 870 260" fill="none" stroke="{stroke_color}" stroke-width="2" stroke-dasharray="4,4"/>')
    connections_svg_lines.append(f'<path d="M 1030 470 Q 950 470 900 420" fill="none" stroke="{stroke_color}" stroke-width="2" stroke-dasharray="4,4"/>')
    
    for i, badge in enumerate(badges[:4]):
        label = badge.get("label", "Tech").strip()
        color = badge.get("color", "#3b82f6").strip()
        bx, by = badge_positions[i]
        label_escaped = label.replace("&", "&amp;").replace("<", "&lt;").replace(">/", "&gt;")
        bw = len(label) * 9 + 50
        if bw < 100:
            bw = 100
            
        if theme == "theme2":
            badges_svg_lines.append(f"""
    <g transform="translate({bx}, {by})" filter="url(#shadow)">
      <rect x="0" y="0" width="{bw}" height="42" rx="10" fill="#111827" stroke="{color}" stroke-width="2"/>
      <circle cx="20" cy="21" r="6" fill="{color}"/>
      <text x="36" y="26" font-family="system-ui, sans-serif" font-size="14" font-weight="700" fill="#f3f4f6">{label_escaped}</text>
    </g>""")
        elif theme == "theme3":
            badges_svg_lines.append(f"""
    <g transform="translate({bx}, {by})" filter="url(#shadow)">
      <rect x="0" y="0" width="{bw}" height="42" rx="10" fill="#ffffff" stroke="#e2e8f0" stroke-width="1.5"/>
      <circle cx="20" cy="21" r="6" fill="{color}"/>
      <text x="36" y="26" font-family="system-ui, sans-serif" font-size="14" font-weight="700" fill="#0f172a">{label_escaped}</text>
    </g>""")
        else:
            badges_svg_lines.append(f"""
    <g transform="translate({bx}, {by})" filter="url(#shadow)">
      <rect x="0" y="0" width="{bw}" height="42" rx="10" fill="#ffffff" stroke="#cbd5e1" stroke-width="1.5"/>
      <circle cx="20" cy="21" r="6" fill="{color}"/>
      <text x="36" y="26" font-family="system-ui, sans-serif" font-size="14" font-weight="700" fill="#1e293b">{label_escaped}</text>
    </g>""")
            
    badges_svg_str = "\n".join(badges_svg_lines)
    connections_svg_str = "\n".join(connections_svg_lines)
    
    # 4. Templates
    if theme == "theme2":
        # AI theme
        svg = f"""<svg viewBox="0 0 1200 800" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <filter id="shadow" x="-10%" y="-10%" width="120%" height="120%">
      <feDropShadow dx="0" dy="4" stdDeviation="4" flood-color="#000000" flood-opacity="0.3"/>
    </filter>
    <linearGradient id="purpleGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#7c3aed"/>
      <stop offset="100%" stop-color="#db2777"/>
    </linearGradient>
    <pattern id="cyberGrid" width="50" height="50" patternUnits="userSpaceOnUse">
      <path d="M 50 0 L 0 0 0 50" fill="none" stroke="#111827" stroke-width="1"/>
    </pattern>
  </defs>

  <rect x="0" y="0" width="1200" height="800" fill="#090d16"/>
  <rect x="0" y="0" width="1200" height="740" fill="url(#cyberGrid)"/>

  <path d="M 0 0 L 540 0 Q 590 370 470 740 L 0 740 Z" fill="#0f172a" opacity="0.95"/>
  <path d="M 0 0 L 540 0 Q 590 370 470 740 L 0 740 Z" fill="none" stroke="url(#purpleGrad)" stroke-width="3"/>

  <g transform="translate(80, 50)" color="#ffffff">
    {logo_content_svg}
  </g>

  <g id="title-text" transform="translate(80, 200)">
     {title_lines_svg_str}
  </g>

  <text x="80" y="470" font-family="system-ui, sans-serif" font-size="16" font-weight="500" fill="#cbd5e1" opacity="0.9">
     {subtext_svg_str}
  </text>

  <g transform="translate(80, 560)">
    <rect x="0" y="0" width="180" height="48" rx="24" fill="url(#purpleGrad)" filter="url(#shadow)"/>
    <text x="90" y="29" font-family="system-ui, sans-serif" font-size="14" font-weight="800" fill="#ffffff" text-anchor="middle" letter-spacing="1">{cta_text}</text>
    <path d="M 145 20 L 151 24 L 145 28 M 138 24 L 150 24" fill="none" stroke="#ffffff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
  </g>

  {connections_svg_str}

  <circle cx="850" cy="380" r="140" fill="#7c3aed" opacity="0.08" filter="blur(30px)"/>

  <g id="laptop" transform="translate(60, 20)">
    <rect x="660" y="230" width="360" height="230" rx="12" fill="#030712" stroke="#4b5563" stroke-width="4"/>
    <rect x="670" y="240" width="340" height="210" rx="4" fill="#090d16"/>
    <g transform="translate(840, 345)">
      <circle cx="-40" cy="-30" r="8" fill="#a855f7"/>
      <circle cx="40" cy="-30" r="8" fill="#ec4899"/>
      <circle cx="-60" cy="20" r="8" fill="#3b82f6"/>
      <circle cx="60" cy="20" r="8" fill="#14b8a6"/>
      <circle cx="0" cy="40" r="10" fill="#22d3ee"/>
      <line x1="-40" y1="-30" x2="0" y2="40" stroke="#4b5563" stroke-width="2"/>
      <line x1="40" y1="-30" x2="0" y2="40" stroke="#4b5563" stroke-width="2"/>
      <line x1="-60" y1="20" x2="0" y2="40" stroke="#4b5563" stroke-width="2"/>
      <line x1="60" y1="20" x2="0" y2="40" stroke="#4b5563" stroke-width="2"/>
      <line x1="-40" y1="-30" x2="40" y2="-30" stroke="#4b5563" stroke-width="1.5" stroke-dasharray="2,2"/>
    </g>
    <text x="840" y="420" font-family="system-ui, sans-serif" font-size="28" font-weight="900" fill="#22d3ee" text-anchor="middle" letter-spacing="3">{screen_title_esc}</text>
    
    <polygon points="610,460 1070,460 1030,485 650,485" fill="#1f2937"/>
    <polygon points="650,485 1030,485 1020,492 660,492" fill="#111827"/>
    <rect x="800" y="465" width="80" height="14" rx="2" fill="#111827"/>
  </g>

  {badges_svg_str}

  <rect x="0" y="740" width="1200" height="60" fill="#030712"/>
  <g transform="translate(0, 740)">
    <g transform="translate(180, 35)">
      <circle cx="-15" cy="-5" r="12" fill="#7c3aed"/>
      <path d="M -19.5 -8.5 C -19.5 -5 -15 -0.5 -11.5 -0.5 C -10 -0.5 -9.5 -2 -10.5 -3 L -12 -4.5 C -12.5 -5 -13.5 -5 -14 -4.5 L -15 -3.5 C -16 -4 -17 -5 -17.5 -6 L -16.5 -7 C -16 -7.5 -16 -8.5 -16.5 -9 L -18 -10.5 C -19 -11.5 -19.5 -10 -19.5 -8.5 Z" fill="#ffffff"/>
      <text x="5" y="0" fill="#ffffff" font-family="system-ui, sans-serif" font-size="14" font-weight="700">+91 9875905952</text>
    </g>
    <g transform="translate(520, 35)">
      <circle cx="-15" cy="-5" r="12" fill="#7c3aed"/>
      <circle cx="-15" cy="-5" r="7" fill="none" stroke="#ffffff" stroke-width="1.5"/>
      <path d="M -22 -5 L -8 -5 M -15 -12 L -15 2 M -19 -8 Q -15 -5 -11 -8 M -19 -2 Q -15 -5 -11 -2" fill="none" stroke="#ffffff" stroke-width="1"/>
      <text x="5" y="0" fill="#ffffff" font-family="system-ui, sans-serif" font-size="14" font-weight="700">www.devexhub.in</text>
    </g>
    <g transform="translate(860, 35)">
      <circle cx="-15" cy="-5" r="12" fill="#7c3aed"/>
      <rect x="-21" y="-10" width="12" height="9" rx="1" fill="none" stroke="#ffffff" stroke-width="1.5"/>
      <path d="M -21 -9 L -15 -5 L -9 -9" fill="none" stroke="#ffffff" stroke-width="1.5"/>
      <text x="5" y="0" fill="#ffffff" font-family="system-ui, sans-serif" font-size="14" font-weight="700">info@devexhub.com</text>
    </g>
  </g>
</svg>"""

    elif theme == "theme3":
        # Web Dev / Full Stack White-Sidebar theme
        svg = f"""<svg viewBox="0 0 1200 800" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <filter id="shadow" x="-10%" y="-10%" width="120%" height="120%">
      <feDropShadow dx="0" dy="4" stdDeviation="4" flood-color="#0f172a" flood-opacity="0.12"/>
    </filter>
    <linearGradient id="darkBlueGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#0a192f"/>
      <stop offset="100%" stop-color="#172a45"/>
    </linearGradient>
  </defs>

  <rect x="0" y="0" width="1200" height="800" fill="#ffffff"/>

  <path d="M 720 0 Q 640 370 760 740 L 1200 740 L 1200 0 Z" fill="url(#darkBlueGrad)"/>

  <g transform="translate(80, 50)" color="#0a122c">
    {logo_content_svg}
  </g>

  <g id="title-text" transform="translate(80, 200)">
     {title_lines_svg_str}
  </g>

  <text x="80" y="470" font-family="system-ui, sans-serif" font-size="16" font-weight="500" fill="#475569" opacity="0.95">
     {subtext_svg_str}
  </text>

  <g transform="translate(80, 560)">
    <rect x="0" y="0" width="180" height="48" rx="24" fill="#0a122c" filter="url(#shadow)"/>
    <text x="90" y="29" font-family="system-ui, sans-serif" font-size="14" font-weight="800" fill="#ffffff" text-anchor="middle" letter-spacing="1">{cta_text}</text>
    <path d="M 145 20 L 151 24 L 145 28 M 138 24 L 150 24" fill="none" stroke="#ffffff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
  </g>

  {connections_svg_str}

  <g id="laptop" transform="translate(80, 20)">
    <rect x="660" y="230" width="360" height="230" rx="12" fill="#0f172a" stroke="#4b5563" stroke-width="4"/>
    <rect x="670" y="240" width="340" height="210" rx="4" fill="#020617"/>
    <g transform="translate(685, 255)" fill="#60a5fa" font-family="Courier, monospace" font-size="11">
      <text x="0" y="0">
        <tspan x="0" dy="16" fill="#f43f5e">&lt;?php</tspan>
        <tspan x="0" dy="16" fill="#e2e8f0">class WebApp {{</tspan>
        <tspan x="0" dy="16" fill="#e2e8f0">  public function render() {{</tspan>
        <tspan x="4" dy="16" fill="#a855f7">    $theme = "DevexHub";</tspan>
        <tspan x="4" dy="16" fill="#34d399">    return view($theme);</tspan>
        <tspan x="0" dy="16" fill="#e2e8f0">  }}</tspan>
        <tspan x="0" dy="16" fill="#e2e8f0">}}</tspan>
      </text>
    </g>
    <rect x="850" y="405" width="140" height="34" rx="6" fill="#1e293b" opacity="0.9"/>
    <text x="920" y="427" font-family="system-ui, sans-serif" font-size="13" font-weight="800" fill="#ffffff" text-anchor="middle">{screen_subtitle_esc}</text>
    
    <polygon points="610,460 1070,460 1030,485 650,485" fill="#475569"/>
    <polygon points="650,485 1030,485 1020,492 660,492" fill="#334155"/>
    <rect x="800" y="465" width="80" height="14" rx="2" fill="#334155"/>
  </g>

  {badges_svg_str}

  <rect x="0" y="740" width="1200" height="60" fill="#0a122c"/>
  <g transform="translate(0, 740)">
    <g transform="translate(180, 35)">
      <circle cx="-15" cy="-5" r="12" fill="#0284c7"/>
      <path d="M -19.5 -8.5 C -19.5 -5 -15 -0.5 -11.5 -0.5 C -10 -0.5 -9.5 -2 -10.5 -3 L -12 -4.5 C -12.5 -5 -13.5 -5 -14 -4.5 L -15 -3.5 C -16 -4 -17 -5 -17.5 -6 L -16.5 -7 C -16 -7.5 -16 -8.5 -16.5 -9 L -18 -10.5 C -19 -11.5 -19.5 -10 -19.5 -8.5 Z" fill="#ffffff"/>
      <text x="5" y="0" fill="#ffffff" font-family="system-ui, sans-serif" font-size="14" font-weight="700">+91 9875905952</text>
    </g>
    <g transform="translate(520, 35)">
      <circle cx="-15" cy="-5" r="12" fill="#0284c7"/>
      <circle cx="-15" cy="-5" r="7" fill="none" stroke="#ffffff" stroke-width="1.5"/>
      <path d="M -22 -5 L -8 -5 M -15 -12 L -15 2 M -19 -8 Q -15 -5 -11 -8 M -19 -2 Q -15 -5 -11 -2" fill="none" stroke="#ffffff" stroke-width="1"/>
      <text x="5" y="0" fill="#ffffff" font-family="system-ui, sans-serif" font-size="14" font-weight="700">www.devexhub.in</text>
    </g>
    <g transform="translate(860, 35)">
      <circle cx="-15" cy="-5" r="12" fill="#0284c7"/>
      <rect x="-21" y="-10" width="12" height="9" rx="1" fill="none" stroke="#ffffff" stroke-width="1.5"/>
      <path d="M -21 -9 L -15 -5 L -9 -9" fill="none" stroke="#ffffff" stroke-width="1.5"/>
      <text x="5" y="0" fill="#ffffff" font-family="system-ui, sans-serif" font-size="14" font-weight="700">info@devexhub.com</text>
    </g>
  </g>
</svg>"""

    else:
        # SEO / Marketing (theme1)
        svg = f"""<svg viewBox="0 0 1200 800" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <filter id="shadow" x="-10%" y="-10%" width="120%" height="120%">
      <feDropShadow dx="0" dy="4" stdDeviation="4" flood-color="#0f172a" flood-opacity="0.15"/>
    </filter>
    <linearGradient id="blueGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#0284c7"/>
      <stop offset="100%" stop-color="#1e3a8a"/>
    </linearGradient>
    <pattern id="hexGrid" width="40" height="69.282" patternUnits="userSpaceOnUse">
      <path d="M 40 0 L 20 11.547 L 0 0 L 0 23.094 L 20 34.641 L 40 23.094 Z M 0 34.641 L 20 46.188 L 0 57.735 L 0 80.829 L 20 92.376 L 40 80.829 L 40 57.735 L 20 46.188" fill="none" stroke="#cbd5e1" stroke-width="0.8"/>
    </pattern>
  </defs>

  <rect x="0" y="0" width="1200" height="800" fill="#f8fafc"/>
  <rect x="450" y="0" width="750" height="740" fill="url(#hexGrid)" opacity="0.3"/>

  <path d="M 0 0 L 520 0 Q 570 370 460 740 L 0 740 Z" fill="url(#blueGrad)"/>

  <g transform="translate(80, 50)" color="#ffffff">
    {logo_content_svg}
  </g>

  <g id="title-text" transform="translate(80, 200)">
     {title_lines_svg_str}
  </g>

  <text x="80" y="470" font-family="system-ui, sans-serif" font-size="16" font-weight="500" fill="#e2e8f0" opacity="0.95">
     {subtext_svg_str}
  </text>

  <g transform="translate(80, 560)">
    <rect x="0" y="0" width="180" height="48" rx="24" fill="#0284c7" filter="url(#shadow)"/>
    <text x="90" y="29" font-family="system-ui, sans-serif" font-size="14" font-weight="800" fill="#ffffff" text-anchor="middle" letter-spacing="1">{cta_text}</text>
    <path d="M 145 20 L 151 24 L 145 28 M 138 24 L 150 24" fill="none" stroke="#ffffff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
  </g>

  {connections_svg_str}
  
  <g id="laptop" transform="translate(50, 0)">
    <rect x="660" y="250" width="360" height="230" rx="12" fill="#0f172a" stroke="#334155" stroke-width="4"/>
    <rect x="670" y="260" width="340" height="210" rx="4" fill="#1e293b"/>
    <text x="840" y="360" font-family="system-ui, sans-serif" font-size="52" font-weight="900" fill="#ffffff" text-anchor="middle" letter-spacing="2">{screen_title_esc}</text>
    <circle cx="910" cy="370" r="14" fill="none" stroke="#0284c7" stroke-width="4"/>
    <line x1="920" y1="380" x2="935" y2="395" stroke="#0284c7" stroke-width="4" stroke-linecap="round"/>
    
    <polygon points="610,480 1070,480 1030,505 650,505" fill="#475569"/>
    <polygon points="650,505 1030,505 1020,512 660,512" fill="#334155"/>
    <rect x="800" y="485" width="80" height="16" rx="3" fill="#334155"/>
  </g>

  <g transform="translate(640, 480)">
    <polygon points="-10,-10 10,-10 7,15 -7,15" fill="#f43f5e"/>
    <path d="M 0 -10 Q -15 -25 -20 -30 Q -7 -22 0 -10 Z" fill="#10b981"/>
    <path d="M 0 -10 Q 15 -25 20 -30 Q 7 -22 0 -10 Z" fill="#10b981"/>
    <path d="M 0 -10 Q 0 -35 0 -40 Q 5 -25 0 -10 Z" fill="#10b981"/>
  </g>
  
  <g transform="translate(970, 485) rotate(15)">
    <rect x="0" y="0" width="70" height="50" rx="4" fill="#ffffff" stroke="#cbd5e1" stroke-width="2"/>
    <path d="M -5 10 L 2 8 M -3 20 L 4 18 M -1 30 L 6 28" stroke="#94a3b8" stroke-width="2.5"/>
    <rect x="80" y="-10" width="5" height="55" rx="1.5" fill="#0f172a" transform="rotate(-45 80 -10)"/>
  </g>

  {badges_svg_str}

  <rect x="0" y="740" width="1200" height="60" fill="#0a122c"/>
  <g transform="translate(0, 740)">
    <g transform="translate(180, 35)">
      <circle cx="-15" cy="-5" r="12" fill="#0284c7"/>
      <path d="M -19.5 -8.5 C -19.5 -5 -15 -0.5 -11.5 -0.5 C -10 -0.5 -9.5 -2 -10.5 -3 L -12 -4.5 C -12.5 -5 -13.5 -5 -14 -4.5 L -15 -3.5 C -16 -4 -17 -5 -17.5 -6 L -16.5 -7 C -16 -7.5 -16 -8.5 -16.5 -9 L -18 -10.5 C -19 -11.5 -19.5 -10 -19.5 -8.5 Z" fill="#ffffff"/>
      <text x="5" y="0" fill="#ffffff" font-family="system-ui, sans-serif" font-size="14" font-weight="700">+91 9875905952</text>
    </g>
    <g transform="translate(520, 35)">
      <circle cx="-15" cy="-5" r="12" fill="#0284c7"/>
      <circle cx="-15" cy="-5" r="7" fill="none" stroke="#ffffff" stroke-width="1.5"/>
      <path d="M -22 -5 L -8 -5 M -15 -12 L -15 2 M -19 -8 Q -15 -5 -11 -8 M -19 -2 Q -15 -5 -11 -2" fill="none" stroke="#ffffff" stroke-width="1"/>
      <text x="5" y="0" fill="#ffffff" font-family="system-ui, sans-serif" font-size="14" font-weight="700">www.devexhub.in</text>
    </g>
    <g transform="translate(860, 35)">
      <circle cx="-15" cy="-5" r="12" fill="#0284c7"/>
      <rect x="-21" y="-10" width="12" height="9" rx="1" fill="none" stroke="#ffffff" stroke-width="1.5"/>
      <path d="M -21 -9 L -15 -5 L -9 -9" fill="none" stroke="#ffffff" stroke-width="1.5"/>
      <text x="5" y="0" fill="#ffffff" font-family="system-ui, sans-serif" font-size="14" font-weight="700">info@devexhub.com</text>
    </g>
  </g>
</svg>"""

    return svg


def generate_svg_cover_via_gpt(title: str, category: str) -> str:
    """Uses GPT-4o-mini to plan a stylized blog cover, then renders it using a local template."""
    prompt = f"""You are an expert graphic designer. You are designing a blog cover layout for:
BLOG TITLE: {title}
BLOG CATEGORY: {category}

Based on this category and title, you must plan the cover illustration. We support three visual themes:
- "theme1" (SEO / Digital Marketing / Business / Growth): Light right side, blue/indigo curved gradient sidebar on the left.
- "theme2" (Artificial Intelligence / Technology / Machine Learning): Dark high-tech theme with a neon purple-to-pink glowing curved sidebar.
- "theme3" (Web Development / Coding / Full Stack / PHP / software engineering): White background on the left, dark blue/indigo curved sidebar on the right.

Your task is to analyze the title and category, select the best theme, and provide structured details for rendering.

Return a JSON object with the following keys:
1. "theme": Select "theme1", "theme2", or "theme3".
   - Select "theme2" for AI, machine learning, agents, or deep learning.
   - Select "theme3" for coding, web development, PHP, full stack, database, or engineering.
   - Select "theme1" for SEO, marketing, business, growth, or any general topics.
2. "title_lines": Break the title into 2-4 short lines (each line under 28 characters) so it fits inside the left column beautifully.
   Each line in "title_lines" is an object:
   {{
     "text": "The line text",
     "type": "plain" | "boxed" | "accent"
   }}
   - "boxed": wraps the text in a styled rectangle border (use for key keywords, max 1 boxed line per title).
   - "accent": uses the secondary highlight color (light blue or purple).
   - "plain": uses the standard text color (white or dark blue depending on the theme).
3. "subtext": A concise 1-2 sentence description summarizing the value of the post (max 120 characters total).
4. "cta_text": The button text, e.g. "READ MORE", "LEARN MORE", "EXPLORE NOW".
5. "laptop_screen": An object representing what is shown on the laptop:
   - "title": A short bold title (1-2 words, e.g., "SEO", "AI", "CODE", "PHP", "ML") to display.
   - "subtitle": A tiny subtitle (2-3 words, e.g. "Search Analytics", "Neural Network", "Full Stack").
6. "badges": A list of exactly 4 floating badge cards. Each badge represents a relevant tool, technology, or concept:
   - For example:
     - For Web Dev: "HTML/CSS", "JavaScript", "PHP", "React", "NodeJS", "MySQL", "GitHub".
     - For AI: "ChatGPT", "Gemini", "Perplexity", "Claude", "LLMs", "Agents", "NLP".
     - For SEO: "Google", "Rankings", "Keywords", "Analytics", "Audits", "Content".
   Each badge is an object:
   {{
     "label": "Badge label (max 12 chars)",
     "color": "A hex color code for the badge icon (e.g. #3b82f6, #ec4899, #10b981)"
   }}

Do NOT include any markdown formatting. Return ONLY the raw JSON object."""

    try:
        response = client.chat.completions.create(
            model=MODEL,
            messages=[{'role': 'user', 'content': prompt}],
            max_tokens=800,
            temperature=0.4,
            response_format={"type": "json_object"},
        )
        
        import json
        data = json.loads(response.choices[0].message.content.strip())
        svg_content = build_svg_from_data(data)
        if svg_content:
            return svg_content
    except Exception as e:
        logger.warning(f"GPT SVG cover planning failed: {e}. Falling back to local heuristic.")
        
    # Heuristic Fallback
    try:
        import json
        theme = "theme1"
        cat_lower = category.lower() if category else ""
        title_lower = title.lower() if title else ""
        if any(k in cat_lower or k in title_lower for k in ["ai", "agent", "machine learning", "intelligence", "neural", "gpt"]):
            theme = "theme2"
        elif any(k in cat_lower or k in title_lower for k in ["web", "develop", "php", "code", "programming", "sql", "html", "css", "js", "javascript", "stack"]):
            theme = "theme3"
            
        words = title.split()
        lines = []
        curr = []
        curr_len = 0
        for w in words:
            if curr_len + len(w) + 1 > 24:
                lines.append(" ".join(curr))
                curr = [w]
                curr_len = len(w)
            else:
                curr.append(w)
                curr_len += len(w) + 1
        if curr:
            lines.append(" ".join(curr))
            
        title_lines = []
        for i, line in enumerate(lines[:4]):
            ltype = "boxed" if i == 1 else ("accent" if i == 3 else "plain")
            title_lines.append({"text": line, "type": ltype})
            
        fallback_data = {
            "theme": theme,
            "title_lines": title_lines,
            "subtext": f"A detailed guide to {title}.",
            "cta_text": "READ MORE",
            "laptop_screen": {
                "title": "DEVEX",
                "subtitle": "Knowledge Base"
            },
            "badges": [
                {"label": "Devex Hub", "color": "#0ea5e9"},
                {"label": "Success", "color": "#10b981"},
                {"label": "Learning", "color": "#f59e0b"},
                {"label": "Growth", "color": "#8b5cf6"}
            ]
        }
        return build_svg_from_data(fallback_data)
    except Exception as fallback_err:
        logger.error(f"Fallback SVG generation also failed: {fallback_err}")
    return ""


def generate_for_idea(idea_id: int):
    """Main entry point called by Celery task."""
    from .models import ContentIdea, ContentDraft
    
    idea = ContentIdea.objects.select_related('website').get(pk=idea_id)
    website = idea.website
    
    try:
        cover_image_url = ""
        category_name = ""
        if idea.platform == 'blog':
            content_data = generate_blog_post(idea, website)
            category_name = content_data.get('category', 'General')
            
            # Generate cover image using GPT (SVG vector art)
            try:
                from django.conf import settings
                import os
                import uuid
                
                logger.info(f"Generating GPT SVG cover image for blog: {idea.title}")
                svg_code = generate_svg_cover_via_gpt(idea.title, category_name)
                
                if svg_code:
                    media_dir = os.path.join(settings.BASE_DIR, 'frontend', 'media')
                    os.makedirs(media_dir, exist_ok=True)
                    
                    filename = f"blog_cover_{uuid.uuid4().hex}.svg"
                    filepath = os.path.join(media_dir, filename)
                    
                    with open(filepath, 'w', encoding='utf-8') as f:
                        f.write(svg_code)
                        
                    cover_image_url = f"/static/media/{filename}"
                    logger.info(f"Successfully generated and saved GPT SVG cover image to: {cover_image_url}")
            except Exception as img_err:
                logger.warning(f"Failed to generate GPT SVG cover image: {img_err}")
        else:
            content_data = generate_social_post(idea, website, idea.platform)
        
        draft = ContentDraft.objects.create(
            idea=idea,
            website=website,
            platform=idea.platform,
            title=content_data.get('title', idea.title),
            body=content_data.get('body', ''),
            excerpt=content_data.get('excerpt', ''),
            meta_description=content_data.get('meta_description', ''),
            tags=content_data.get('tags', []),
            ai_model=MODEL,
            generation_prompt=content_data.get('generation_prompt', ''),
            status='draft',
            cover_image=cover_image_url,
            category=category_name,
        )
        
        idea.status = 'done'
        idea.save(update_fields=['status'])
        
        return draft.id
    
    except Exception as e:
        logger.warning(f"OpenAI generation failed, falling back to local simulation: {e}")
        try:
            if idea.platform == 'blog':
                body = f"""<h2>The Guide to {idea.title}</h2>
                <p>This is a simulated high-quality blog post about <strong>{idea.title}</strong>, prepared automatically by the Cadence content assistant.</p>
                <h3>Introduction</h3>
                <p>Every brand needs a voice that resonates. When writing about {idea.title}, the key is to stay authentic, concise, and focused on value. In this article, we'll cover the core principles and how you can implement them today.</p>
                <h3>Core Strategies</h3>
                <p>First, identify your primary audience. Second, keep paragraphs short and scannable. Finally, add a clear call to action at the end to drive conversions.</p>
                <h3>Conclusion</h3>
                <p>Ready to level up? Start drafting your own content or let Cadence help you automate it.</p>"""
                excerpt = f"A complete guide to {idea.title}. Learn the core strategies and how to implement them."
                tags = ["marketing", "seo", "blogging"]
            else:
                body = f"🚀 Exploring {idea.title}! Consistent content is key to building a strong digital presence. What are your thoughts on this? 👇 #cadence #contentmarketing #ai"
                excerpt = body
                tags = ["content", "ai"]

            draft = ContentDraft.objects.create(
                idea=idea,
                website=website,
                platform=idea.platform,
                title=idea.title,
                body=body,
                excerpt=excerpt,
                meta_description="",
                tags=tags,
                ai_model='mock-gpt-fallback',
                generation_prompt='Simulated Prompt (OpenAI Fallback)',
                status='draft',
                cover_image="",
                category="Web Development" if idea.platform == 'blog' else "",
            )
            idea.status = 'done'
            idea.save(update_fields=['status'])
            return draft.id
        except Exception as inner_e:
            idea.status = 'failed'
            idea.save(update_fields=['status'])
            logger.error(f"Fallback generation also failed: {inner_e}")
            raise e


def analyze_website_context(structure_text: str) -> dict:
    """
    Uses GPT to extract structured metadata (industry, tone, topics, brand_colors, avg_read_time)
    from the crawled structure text.
    """
    prompt = f"""Analyze this website structure and content:
{structure_text[:6000]}

Extract the following details as a JSON object:
1. "industry": A single professional industry name (e.g. "Food & Beverage", "Technology", "Fitness & Health", "Travel & Tourism", "Fashion & Apparel").
2. "tone": A description of the writing tone (e.g. "Warm, artisanal", "Professional, technical", "Energetic, motivational", "Friendly, casual").
3. "topics": A list of up to 10 specific core topics discussed on the site (e.g. ["Specialty coffee", "Latte art", "Brewing guides"]).
4. "brand_colors": A list of 5 hex color codes representing the visual brand palette (suggested colors based on the website context if CSS is not present). Return EXACT hex codes (e.g. ["#b45309", "#78350f", "#f5e6d3", "#1c1917", "#d97706"]).
5. "avg_read_time": Estimate the average read time of a typical article on the site (e.g. "4.5m").

Return ONLY a valid JSON object with these keys. Do NOT include markdown code blocks."""

    try:
        response = client.chat.completions.create(
            model=MODEL,
            messages=[{'role': 'user', 'content': prompt}],
            max_tokens=600,
            temperature=0.3,
            response_format={"type": "json_object"},
        )
        import json
        return json.loads(response.choices[0].message.content)
    except Exception as e:
        logger.error(f"Failed to analyze website context with GPT: {e}")
        return {
            "industry": "General Business",
            "tone": "Professional, engaging",
            "topics": ["Company news", "Industry insights", "Product updates"],
            "brand_colors": ["#6366f1", "#4f46e5", "#f5f3ff", "#1f2937", "#a5b4fc"],
            "avg_read_time": "3.5m"
        }