"""
Scrapes a website to extract blog structure, tone, and style context.
Uses requests + BeautifulSoup for static sites.
Falls back to Playwright for JS-rendered sites.
"""
import re
import time
import logging
import datetime
from urllib.parse import urljoin, urlparse
from typing import Optional

import requests
from bs4 import BeautifulSoup
from django.utils.dateparse import parse_datetime
from dateutil.parser import parse as parse_date
from django.utils import timezone

logger = logging.getLogger(__name__)

SCRAPE_HEADERS = {
    'User-Agent': ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
                   'AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36')
}

MAX_PAGES = 30   # Upgraded crawl limit: crawl up to 30 pages per website

CTA_KEYWORDS = {
    'buy', 'order', 'sign up', 'join', 'get', 'subscribe', 'download', 'contact',
    'start', 'register', 'try', 'learn more', 'explore', 'read more', 'click here',
    'shop', 'purchase', 'book', 'schedule', 'view'
}


def get_url_priority(url: str) -> int:
    """Heuristic priority: blog/article pages first, standard pages next, pagination last."""
    url_lower = url.lower()
    # Pagination patterns
    if 'page=' in url_lower or re.search(r'/page/\d+/?$', url_lower):
        return 3
    # Blog / Article heuristics
    if any(k in url_lower for k in ['/blog/', '/post/', '/article/', '/news/', '/stories/', '/posts/']):
        return 1
    return 2


def parse_pub_date(date_str: str) -> Optional[datetime.datetime]:
    """Parse string representation of publication date into timezone-aware datetime."""
    if not date_str:
        return None
    try:
        dt = parse_datetime(date_str)
        if dt:
            if timezone.is_naive(dt):
                dt = timezone.make_aware(dt)
            return dt
        # dateutil parser fallback
        dt = parse_date(date_str)
        if dt:
            if timezone.is_naive(dt):
                dt = timezone.make_aware(dt)
            return dt
    except Exception:
        pass
    return None


def scrape_website(url: str) -> dict:
    """
    Entry point. Returns dict with:
    - pages: list of scraped page dictionaries
    - structure_summary: str (raw text summary for AI)
    """
    pages = []
    visited = set()
    to_visit = [url]
    base_domain = urlparse(url).netloc

    while to_visit and len(pages) < MAX_PAGES:
        # Sort queue so higher priority URLs (priority value 1) are popped first
        to_visit.sort(key=get_url_priority)
        current_url = to_visit.pop(0)
        
        if current_url in visited:
            continue
        visited.add(current_url)

        logger.info(f"Scraping page ({len(pages)+1}/{MAX_PAGES}): {current_url}")
        page_data = _scrape_page(current_url)
        if not page_data:
            continue

        pages.append(page_data)

        # Discover internal links
        for link in page_data.get('internal_links', []):
            if link not in visited and urlparse(link).netloc == base_domain:
                to_visit.append(link)
                
        # Deduplicate to_visit
        to_visit = list(set(to_visit))

    return {
        'pages': pages,
        'structure_summary': _build_summary(pages),
    }


def _scrape_page(url: str) -> Optional[dict]:
    """Scrapes a page using requests with backoff retry, falling back to Playwright if needed."""
    retries = 3
    backoff = 2
    resp_text = None
    
    for attempt in range(retries):
        try:
            resp = requests.get(url, headers=SCRAPE_HEADERS, timeout=15)
            resp.raise_for_status()
            resp_text = resp.text
            break
        except requests.RequestException as e:
            if attempt == retries - 1:
                logger.warning(f"Failed to scrape {url} via requests after {retries} attempts: {e}")
            else:
                sleep_time = backoff ** attempt
                logger.info(f"Retrying scrape of {url} in {sleep_time}s due to: {e}")
                time.sleep(sleep_time)

    if not resp_text:
        # Fall back to Playwright if static requests failed
        logger.info(f"Static request failed. Falling back to Playwright for {url}")
        return _scrape_page_playwright(url)

    soup = BeautifulSoup(resp_text, 'html.parser')
    
    # Heuristic: if page is mostly empty / JS-heavy, try Playwright fallback
    body_text = soup.body.get_text(strip=True) if soup.body else ""
    if len(body_text) < 200:
        logger.info(f"Page body has minimal text ({len(body_text)} chars). Retrying with Playwright...")
        pw_result = _scrape_page_playwright(url)
        if pw_result:
            return pw_result

    return _extract_from_soup(soup, url, resp_text)


def _scrape_page_playwright(url: str) -> Optional[dict]:
    """Fallback for JS-rendered websites using Playwright."""
    try:
        from playwright.sync_api import sync_playwright
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            page = browser.new_page()
            page.goto(url, timeout=20000, wait_until='networkidle')
            html = page.content()
            browser.close()
        
        soup = BeautifulSoup(html, 'html.parser')
        return _extract_from_soup(soup, url, html)
    except Exception as e:
        logger.error(f"Playwright fallback failed for {url}: {e}")
        return None


def _score_content_nodes(parent):
    """Scores div/section/article elements based on text length, classes, and paragraph/link ratios."""
    candidates = parent.find_all(['div', 'section', 'article', 'main'])
    if not candidates:
        return parent
        
    best_node = parent
    best_score = -999999
    
    for node in candidates:
        text = node.get_text(strip=True)
        if len(text) < 100:
            continue
            
        score = 0
        paragraphs = node.find_all('p')
        score += len(paragraphs) * 10
        
        headings = node.find_all(['h2', 'h3', 'h4'])
        score += len(headings) * 5
        
        # Link density check
        words = text.split()
        if words:
            links = node.find_all('a')
            link_words = sum(len(a.get_text(strip=True).split()) for a in links)
            density = link_words / len(words)
            if density > 0.3:
                score -= 100
            score -= int(density * 50)
            
        # Class / ID matching
        node_class = " ".join(node.get('class', [])).lower()
        node_id = str(node.get('id', '')).lower()
        
        positive_patterns = {'content', 'article', 'post', 'body', 'entry-content', 'post-content', 'main-content', 'blog-post'}
        negative_patterns = {'sidebar', 'nav', 'footer', 'header', 'aside', 'menu', 'comments', 'share', 'social', 'widget', 'ads', 'banner'}
        
        if any(p in node_class or p in node_id for p in positive_patterns):
            score += 50
        if any(n in node_class or n in node_id for n in negative_patterns):
            score -= 100
            
        if score > best_score:
            best_score = score
            best_node = node
            
    return best_node


def _clean_html_structure(node) -> str:
    """Retains structural tags (headings, lists, blockquotes, paragraphs) and strips noise/interactive tags."""
    if not node:
        return ""
    clean_soup = BeautifulSoup(str(node), 'html.parser')
    allowed_tags = {'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'p', 'ul', 'ol', 'li', 'blockquote', 'pre', 'code'}
    
    for tag in clean_soup.find_all(True):
        if tag.name not in allowed_tags:
            if tag.name in {'div', 'section', 'article', 'main', 'span', 'body', 'html'}:
                tag.unwrap()
            else:
                tag.decompose()
                
    return str(clean_soup).strip()


def _classify_page_type_helper(url: str, soup, author: str, pub_date) -> str:
    """Classifies a page into blog post, product page, about page, landing page, or other."""
    url_lower = url.lower()
    path = urlparse(url).path.lower()
    
    # 1. Product page heuristics
    if any(k in path for k in ['/product/', '/shop/', '/store/', '/item/']):
        return 'product page'
    if soup.find('meta', property='og:type', content='product') or soup.find(class_=re.compile(r'add-to-cart|buy-now|price', re.I)):
        return 'product page'
        
    # 2. About page heuristics
    if any(k in path for k in ['/about', '/team', '/who-we-are', '/our-story', '/careers']):
        return 'about page'
    if soup.title and any(k in soup.title.string.lower() for k in ['about us', 'about company', 'our team', 'who we are']):
        return 'about page'
        
    # 3. Blog post heuristics
    if any(k in path for k in ['/blog/', '/post/', '/article/', '/news/', '/stories/', '/posts/']) or re.search(r'/\d{4}/\d{2}/', path):
        return 'blog post'
    if soup.find('article') or (author and pub_date):
        return 'blog post'
    
    # JSON-LD Schema Type checks
    for schema in soup.find_all('script', type='application/ld+json'):
        try:
            import json
            data = json.loads(schema.string)
            schemas = data if isinstance(data, list) else [data]
            for s in schemas:
                s_type = str(s.get('@type', ''))
                if any(t in s_type for t in ['Article', 'BlogPosting', 'NewsArticle']):
                    return 'blog post'
                if s_type == 'Product':
                    return 'product page'
        except Exception:
            pass
            
    # 4. Landing page heuristics
    if any(k in path for k in ['/landing', '/welcome', '/promo', '/features']) or path in {'', '/'}:
        return 'landing page'
        
    return 'other'


def _extract_from_soup(soup: BeautifulSoup, url: str, raw_html: str) -> dict:
    """Extracts structured metadata, headings, main content, CTAs, comments, and page types."""
    title = soup.title.string.strip() if soup.title else ''
    meta_title = ""
    meta_desc = ""
    og_properties = {}
    pub_date = None
    author = ""
    categories_tags = []
    
    # Meta Titles
    meta_t = soup.find('meta', attrs={'property': 'og:title'}) or soup.find('meta', attrs={'name': 'twitter:title'})
    meta_title = meta_t['content'].strip() if meta_t and meta_t.get('content') else title
    
    # Meta Descriptions
    meta_d = soup.find('meta', attrs={'name': 'description'}) or soup.find('meta', attrs={'property': 'og:description'}) or soup.find('meta', attrs={'name': 'twitter:description'})
    meta_desc = meta_d['content'].strip() if meta_d and meta_d.get('content') else ""
    
    # Open Graph properties
    for meta in soup.find_all('meta', property=True):
        prop = meta['property']
        if prop.startswith('og:') and meta.get('content'):
            og_properties[prop[3:]] = meta['content'].strip()
            
    # Publication Date
    time_tag = soup.find('time')
    pub_time_meta = (
        soup.find('meta', attrs={'property': 'article:published_time'}) or 
        soup.find('meta', itemprop='datePublished') or 
        soup.find('meta', attrs={'name': 'pubdate'})
    )
    date_str = ""
    if pub_time_meta and pub_time_meta.get('content'):
        date_str = pub_time_meta['content'].strip()
    elif time_tag and time_tag.get('datetime'):
        date_str = time_tag['datetime'].strip()
    elif time_tag:
        date_str = time_tag.get_text(strip=True)
        
    pub_date = parse_pub_date(date_str)
    
    # Author
    author_meta = (
        soup.find('meta', attrs={'name': 'author'}) or 
        soup.find('meta', attrs={'property': 'article:author'}) or 
        soup.find('meta', attrs={'name': 'twitter:creator'})
    )
    if author_meta and author_meta.get('content'):
        author = author_meta['content'].strip()
    else:
        author_el = soup.find(class_=re.compile(r'author|byline|creator|writer', re.I))
        if author_el:
            author = author_el.get_text(strip=True)
            author = re.sub(r'^by\s+', '', author, flags=re.I).strip()
            
    # Categories / keywords / tags
    keywords_meta = soup.find('meta', attrs={'name': 'keywords'}) or soup.find('meta', attrs={'property': 'article:tag'})
    if keywords_meta and keywords_meta.get('content'):
        categories_tags = [k.strip() for k in keywords_meta['content'].split(',') if k.strip()]
    else:
        section_meta = soup.find('meta', attrs={'property': 'article:section'})
        if section_meta and section_meta.get('content'):
            categories_tags.append(section_meta['content'].strip())

    # Main Content Area
    main_soup = soup.find('main') or soup.find('article') or soup.find('body') or soup
    
    # Try using readability if available and advanced is enabled
    from django.conf import settings
    enable_nlp = getattr(settings, 'ENABLE_ADVANCED_ANALYSIS', False)
    
    extracted = False
    main_content_html = ""
    if enable_nlp:
        try:
            from readability import Document
            doc = Document(raw_html)
            summary_html = doc.summary()
            if summary_html:
                content_soup = BeautifulSoup(summary_html, 'html.parser')
                main_content_html = _clean_html_structure(content_soup)
                extracted = True
        except Exception as e:
            logger.warning(f"Readability-lxml extraction failed: {e}")
            
    if not extracted:
        scored_node = _score_content_nodes(main_soup)
        main_content_html = _clean_html_structure(scored_node)
        
    # Clean text extracted from structured content
    temp_soup = BeautifulSoup(main_content_html, 'html.parser')
    raw_text = temp_soup.get_text(separator=' ', strip=True)
    raw_text = re.sub(r'\s+', ' ', raw_text)[:5000] # Limit database size
    
    # Classify Page Type
    page_type = _classify_page_type_helper(url, soup, author, pub_date)
    
    # Headings Structure
    headings = []
    for level in ['h1', 'h2', 'h3']:
        for h in temp_soup.find_all(level)[:10]:
            text_h = h.get_text(strip=True)
            if text_h:
                headings.append({'level': level, 'text': text_h})
                
    # Image Alt Texts
    image_alts = []
    for img in temp_soup.find_all('img', alt=True):
        alt = img['alt'].strip()
        if alt:
            image_alts.append(alt)
            
    # Call to Actions (CTAs)
    ctas = []
    for element in main_soup.find_all(['a', 'button']):
        el_text = element.get_text(strip=True)
        if not el_text:
            continue
        el_class = " ".join(element.get('class', [])).lower()
        is_cta = False
        if any(c in el_class for c in ['btn', 'button', 'cta', 'signup', 'subscribe', 'register']):
            is_cta = True
        else:
            el_text_lower = el_text.lower()
            if any(el_text_lower.startswith(verb) or f" {verb} " in f" {el_text_lower} " for verb in CTA_KEYWORDS):
                is_cta = True
        if is_cta and len(el_text.split()) <= 8:
            ctas.append(el_text)
    ctas = list(set(ctas))[:10]
    
    # Comments (Up to 5)
    comments = []
    comment_containers = soup.find_all(class_=re.compile(r'comment|discussion|reply|thread', re.I))
    for container in comment_containers:
        for p in container.find_all('p'):
            comm_text = p.get_text(strip=True)
            if len(comm_text) > 15 and comm_text not in comments:
                comments.append(comm_text)
                if len(comments) >= 5:
                    break
        if len(comments) >= 5:
            break
            
    # Discover internal links
    internal_links = []
    base = urlparse(url)
    for a in soup.find_all('a', href=True):
        href = urljoin(url, a['href'])
        if urlparse(href).netloc == base.netloc:
            cleaned_href = href.split('?')[0].split('#')[0]
            internal_links.append(cleaned_href)
            
    return {
        'url': url,
        'title': title,
        'meta_title': meta_title,
        'meta_description': meta_desc,
        'og_properties': og_properties,
        'publication_date': pub_date,
        'author': author,
        'categories_tags': categories_tags,
        'image_alts': image_alts,
        'page_type': page_type,
        'headings': headings,
        'text': raw_text,
        'word_count': len(raw_text.split()),
        'comments': comments,
        'ctas': ctas,
        'main_content': main_content_html,
        'internal_links': list(set(internal_links))[:30],
    }


def _build_summary(pages: list) -> str:
    """Builds a text summary of the website structure to use as AI context."""
    lines = []
    for p in pages:
        lines.append(f"PAGE: {p['title']} ({p['url']})")
        for h in p['headings'][:5]:
            lines.append(f"  {h['level'].upper()}: {h['text']}")
        lines.append(f"  EXCERPT: {p['text'][:300]}")
        lines.append("")
    return '\n'.join(lines)