from rest_framework import serializers
from .models import Website, SocialConnection, ScrapeResult

class SocialConnectionSerializer(serializers.ModelSerializer):
    class Meta:
        model = SocialConnection
        fields = ['id', 'platform', 'make_webhook_url', 'is_active', 'connected_at']
        read_only_fields = ['id', 'connected_at']

class ScrapeResultSerializer(serializers.ModelSerializer):
    class Meta:
        model = ScrapeResult
        fields = [
            'id', 'page_url', 'page_title', 'raw_text', 'heading_structure',
            'meta_title', 'meta_description', 'og_properties', 'publication_date',
            'author', 'categories_tags', 'image_alts', 'page_type',
            'readability_metrics', 'sentiment_metrics', 'entities', 'key_phrases',
            'comments', 'ctas', 'main_content', 'crawled_at'
        ]

class WebsiteSerializer(serializers.ModelSerializer):
    social_connections = SocialConnectionSerializer(many=True, read_only=True)
    owner_email = serializers.EmailField(source='owner.email', read_only=True)
    owner_name = serializers.CharField(source='owner.get_full_name', read_only=True)
    
    class Meta:
        model = Website
        fields = [
            'id', 'name', 'domain', 'url', 'industry', 'tone', 'topics',
            'status', 'color', 'brand_colors', 'avg_read_time', 'owner', 'owner_email', 'owner_name',
            'created_at', 'updated_at', 'scrape_summary', 'scrape_status',
            'last_crawled', 'social_connections', 'style_guide', 'needs_crawl'
        ]
        read_only_fields = ['id', 'created_at', 'updated_at', 'owner']