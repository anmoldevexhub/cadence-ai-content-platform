from django.urls import path
from . import views

urlpatterns = [
    # Ideas (admin submits topics)
    path('ideas/', views.ContentIdeaListCreateView.as_view()),
    path('ideas/<int:pk>/', views.ContentIdeaDetailView.as_view()),
    path('ideas/<int:pk>/generate/', views.GenerateContentView.as_view()),
    
    # Drafts
    path('drafts/', views.ContentDraftListView.as_view()),
    path('drafts/<int:pk>/', views.ContentDraftDetailView.as_view()),
    path('drafts/<int:pk>/approve/', views.ApproveDraftView.as_view()),
    path('drafts/<int:pk>/reject/', views.RejectDraftView.as_view()),
    path('drafts/<int:pk>/regenerate/', views.RegenerateDraftView.as_view()),
    path('drafts/<int:pk>/schedule/', views.ScheduleDraftView.as_view()),
    
    # Schedule
    path('scheduled/', views.ScheduledPostListView.as_view()),
    
    # Approvals queue (cross-website pending drafts)
    path('approvals/', views.ApprovalsQueueView.as_view()),
]